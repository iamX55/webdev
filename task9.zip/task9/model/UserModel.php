<?php




include __DIR__.'/../config/DbConnection.php';
class UserModel
{
    private PDO|false $conn;
    private DbConnection $db;
    private string $table ='users';





    public function __construct(){
        $this->db=new DbConnection();
        $this->conn=$this->db->connect();
    }





    /** To Check Whether $email or $mobile exist or not inside Db
     * @param $email
     * @param $mobile
     * @return array|bool|null
     */
    public function existUser($email,$mobile): array|bool|null
    {
        try {
            $stmt = $this->conn->prepare("SELECT `users_id`, `password` FROM `$this->table` WHERE (`users_email`=:name OR `users_mobile`=:mobile)");
            $stmt->execute(array(
                'name'=>$email,
                'mobile'=>$mobile,
            ));
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }





    /** function used to  save register record  into Database
     * @param $email
     * @param $password
     * @param $mobile
     * @return string|string[]|void
     */
    public function registerOperation($name,$email,$mobile,$password,){
        if($this->existUser($email,$mobile)) {
            return [
                'status' => '200',
                'message' => 'Users Already exist'
            ];
        }
        try {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("INSERT INTO `$this->table` (`user_name`,`users_email`,`users_mobile`,`password`) VALUES (:name,:email,:mobile,:password)");
            $stmt->bindparam(":name", $name);
            $stmt->bindParam("email",$email);
            $stmt->bindparam(":mobile", $mobile);
            $stmt->bindparam(":password", $hashedPassword);
            $stmt->execute();
            return $this->conn->lastInsertId();
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }






    /**User login Query function,User can Log_in using email or mobile
     * @param $email
     * @param $password
     * @return bool|array|string
     */
    public function loginOperation($email,$password): bool|array|string
    {

        $result=$this->existUser($email,$email);
        if( empty($result[0]['users_id']) OR empty($result[0]['password'])) {
            return [
                'status' => '200',
                'message' => 'User Dont Exist',
            ];
        }else{
            $storedHashedPassword = $result[0]['password'];
            if (password_verify($password,$storedHashedPassword)) {
                try{
                    $stmt = $this->conn->prepare("SELECT * FROM `$this->table` WHERE (`users_email`=:name OR `users_mobile`=:mobile)");
                    $stmt->execute(array(
                        'name'=>$email,
                        'mobile'=>$email,
                    ));
                    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    if(empty($result)){
                        return [
                            'status' => '200',
                            'message' => 'Password Invalid',
                        ];
                    }else{
                        return $result;
                    }
                } catch (PDOException $e) {
                    return $e->getMessage();
                }
            }else{
                    return [
                        'status' => '200',
                        'message' => 'Password Incorrect',
                    ];
            }
        }

    }



}