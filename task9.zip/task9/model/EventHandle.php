<?php

namespace model;
use DbConnection;
use PDO;
use PDOException;

include __DIR__.'/../config/DbConnection.php';
class EventHandle
{
    private $conn,$db;
    function __construct()
    {
        $this->db = new DbConnection();
        $this->conn=$this->db->connect();
    }
    public function insertOperation($id,$title,$date_time,$date,$time,$json_data){
        $sql="INSERT INTO `event_table`(`uid`,`title`,`date_time`, `date`, `slot`,`json_text`) VALUES ('$id','$title','$date_time','$date','$time','$json_data')";
        try {
            $stmt=$this->conn->prepare($sql);
            $stmt->execute();
            return true;
        }catch ( PDOException $e){
            return "Error: " . $e->getMessage();
        }
    }
    public function readOperation($date){
        $sql="SELECT `json_text` FROM `event_table` WHERE `date`='$date'";
        try {
            $stmt=$this->conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }catch ( PDOException $e){
            return "Error: " . $e->getMessage();
        }
    }
    public function deleteOperation($userId,$date,$slot){
        $sql="DELETE FROM `event_table` WHERE (`uid` ='$userId') AND (`date`='$date') AND  (`slot`='$slot')";
        try {
            $stmt=$this->conn->prepare($sql);
            $stmt->execute();
            return true;
        }catch ( PDOException $e){
            return "Error: " . $e->getMessage();
        }
    }
    public function authenticateOperation($userId,$date,$slot){
        $sql="SELECT * FROM `event_table`  WHERE (`uid` ='$userId') AND (`date`='$date') AND  (`slot`='$slot') ";
        try{
            $stmt=$this->conn->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }catch ( PDOException $err){
            return $err->getMessage();
        }
    }
}