<?php
include __DIR__.'./controller/deleteData.php';
$userId=$_POST['userId'];
//$userId=1;
$date = $_POST['date'];
//$date="2023-9-8";
$slot = $_POST['slot'];
//$slot="4.00 AM - 5.00 AM";
$controller = new \controller\deleteData();
$auth = $controller->authenticateUser($userId,$date,$slot);
if(empty($auth)){
    echo "0";
}else{
    $result = $controller->getData($userId,$date,$slot);
    echo $result;
}



