<?php
    session_start();

     if( !isset($_SESSION['mobile']) AND !isset($_SESSION['email'])  ){
         header("Location:index.php");
     }
     if( !isset($_SESSION['id']) OR !isset($_SESSION['name']) ){
         header("Location:index.php");
     }
    if(isset($_SESSION['ses_time']) && (time() - $_SESSION['ses_time'] > 3600)) {

        session_unset(); session_destroy();
        header("Location:index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- coustoms CSS -->
    <link rel="stylesheet" href="css/style.css">
<!--    jquery cdn-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</head>
<body>
<div class="container">
      <div class="left">
        <div class="calendar">
          <div class="month">
            <i class="fas fa-angle-left prev"></i>
            <div class="date">mm--yyyy</div>
            <i class="fas fa-angle-right next"></i>
          </div>
            <div class="time-table">
                <button class="btn1 add-event1" id="button1" >9.00</button>
                <button class="btn1 add-event1" id="button2">10.00</button>
                <button class="btn1 add-event1" id="button3">11.00</button>
                <button class="btn1 add-event1" id="button4">12.00</button>
                <!--<button class="btn1" id="button5">1.00-2.00(break)</button>-->
                <button class="btn1 add-event1" id="button6">2.00</button>
                <button class="btn1 add-event1" id="button7">3.00</button>
                <button class="btn1 add-event1" id="button8">4.00</button>
                <button class="btn1 add-event1" id="button9">5.00</button>
            </div>
          <div class="weekdays">
            <div>Sun</div>
            <div>Mon</div>
            <div>Tue</div>
            <div>Wed</div>
            <div>Thu</div>
            <div>Fri</div>
            <div>Sat</div>
          </div>
          <!-- in the lower section dates are loaded dynamically -->
          <div class="days"></div>
          <!-- in the upper section  dates are loaded dynamically -->
          <div class="goto-today">
            <div class="goto">
            <!--<input type="text" placeholder="mm/yyyy" class="date-input" />-->
                <input type="date"  id="date-d" class="date-input" />
              <button class="goto-btn">Go</button>
            </div>
            <button class="today-btn">Today</button>
          </div>
        </div>
      </div>
      <div class="right">
        <div class="user"><?php echo $_SESSION['name']?></div>
        <div class="today-date">
          <div class="event-day"></div>
          <div class="event-date"></div>
        </div>
        <!----events class to store all events----->
        <div class="events"></div>
        <!----end of events class ----------------->
        <div class="add-event-wrapper">

          <div class="add-event-header">
            <div class="title">Add Event</div>
            <i class="fas fa-times close"></i>
          </div>
          <!---------------input filed for event details-------------->
          <div class="add-event-body">
            <div class="add-event-input">
              <input type="text" placeholder="Event Name" class="event-name" />
            </div>
            <div class="add-event-input">
              <input type="text" placeholder="Event Time From" id="time-from" class="event-time-from" disabled/>
            </div>
            <div class="add-event-input">
              <input type="text" placeholder="Event Time To" id="time-to" class="event-time-to" disabled/>
            </div>
          </div>
         <!-----------------end of event body----------------------->
          <div class="add-event-footer">
            <!-----------------add event button------------------->
            <button class="add-event-btn">Add Event</button>
          </div>
        </div>
      </div>
<!--      <button class="add-event" >-->
<!--         <i class="fas fa-plus"></i>-->
<!--      </button>-->
    </div>

    <!-- <div class="credits">
        <p>
            Watch Tutorial on Youtube
            <a href="https://youtu.be/6EVgmpm4z5U" target="_blank">Open Source Coding</a>
        </p>
    </div> -->
<?php
    echo '<script> let userId ='.$_SESSION["id"].'</script>' ;
?>
    <script src="js/script.js"></script>

</body>

</html>