<?php


use controller\UserCredential;
include __DIR__.'/controller/UserCredential.php';
// $_POST['formSave'] == "Submit"
session_start();
if( $_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['save'])=='1' ){
    $firstName = $_POST['first_name'] ;
    $lastName = $_POST['last_name'] ;
    $email = $_POST['email'];
    $mobile= $_POST['mobile'];
    $password = $_POST['password'] ;
    if( $_POST['csrf-token'] == $_SESSION['csrf-token'] ){
        //session_unset();
        $controller = new UserCredential();
        $result = $controller->userRegister($firstName." ".$lastName,$email,$mobile,$password);
            //$result = $controller->fetchUserId($email,$mobile);
           // if( empty($result[0]['users_id'])===false OR !empty($result[0]['users_id']) ){
                $_SESSION['name'] = $firstName.' '.$lastName;
                $_SESSION['email'] = $email;
                $_SESSION['mobile'] = $mobile;
                $_SESSION['id'] = $result;
                $_SESSION['ses_time'] = time();
                header("Location:calendar.php");
           // }
        }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- custom css file -->
  <link rel="stylesheet" href="css/signUp.css">
</head>
<body>


    <!--Error message field-->
    <?php
        if(!empty($result)) {
            echo ' <div id ="error-message"><span>' .$result['message'].'</span> </div>';
        }
    ?>



    <!--generating csrf token here and putting it to the hidden input filed-->
    <div class="form-group">
      <?php
        try {
        $_SESSION['csrf-token'] = bin2hex(random_bytes(32));
        } catch (Exception $e) {
          echo $e;
          header("Location:/index.php");
        }
      ?>
    </div>  





    <!-- signup success message popUP -->
    <div id="success-message" class="hidden">
      <img src="images/login.jpg" alt="">
      <p>Sign Up successful!</p>
    </div>










    <!-- main div for both input form  and user login section using social media account -->
    <div id="main" class="form-box">

<!--        <form action="--><?php //echo $_SERVER['PHP_SELF'];?><!--" method="post">-->
<!--            Name: <input type="text" name="name"><br>-->
<!--            <input type="submit" name="formSubmit" value="Submit">-->
<!--        </form>-->




        <!-- user input form for sign up-->
        <form class="form"   name = "formSave" method="POST" action="">
            <span class="title">Sign up</span>
            <span class="subtitle">Create a free account with your email.</span>
            <div class="form-container">
              <input type="hidden" class="form-control" placeholder="" name="csrf-token" value="<?php echo $_SESSION['csrf-token'];?>" required >
              <input type="text" id="id_firstName" class="input" name="first_name" placeholder="First Name" oninput="validateFirstName(this)" required >
              <span id="id_firstError"></span>
              <input type="text" id="id_lastName" class="input" name="last_name" placeholder="Last Name" oninput="validateLastName(this)"  required >
              <span id="id_lastError"></span>
              <input type="email" id="id_email" class="input" name="email" placeholder="Email" oninput="validateEmail(this)" required >
              <span id="id_emailError"></span>
              <input type="number" id="id_mobile" class="input" name="mobile" max="9999999999" placeholder="Mobile"  oninput="validateMobile(this)" required >
              <span id="id_mobileError"> </span>
              <input type="password" id="id_password"  class="input" name="password" placeholder="Password" oninput="validatePassword(this)" required >
              <span id="id_passwordError"></span>
            </div>  
            
              <!-- <input type="submit" name="save"> -->
            <button type="submit"  name = "save" id="sign_button" >Sign Up</button>
            <span>Forget Password?</span>
        </form>





        <!-- user log in section using social media account-->
          <div class="form-section">
            <p>Have an account? <a href="login.php">Log in</a> </p>
          </div>


    </div>





</body>
        <script src="js/script1.js"></script>
        <script  src="js/signUp.js"></script>
</html>