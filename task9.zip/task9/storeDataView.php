<?php
include __DIR__.'/controller/sendData.php';
$data =$_POST['data'];
//echo $data;
$decode_data=json_decode($data);
//var_dump($decode_data);
$title = $decode_data->title;
$time = $decode_data->time;
$date = $decode_data->date;
$uid=$_POST['id'];
                                                                                            //change date format according to data base
                                                                                            //$dateComponents = explode('-', $date);
                                                                                            //
                                                                                            //// Extract year, month, and day
                                                                                            //$year = $dateComponents[0];
                                                                                            //$month = $dateComponents[1];
                                                                                            //$day = $dateComponents[2];
                                                                                            //
                                                                                            //// Ensure that month and day are two digits by padding with '0' if necessary
                                                                                            //$month = str_pad($month, 2, '0', STR_PAD_LEFT);
                                                                                            //$day = str_pad($day, 2, '0', STR_PAD_LEFT);
                                                                                            //
                                                                                            //// Create the formatted date string//from "2020-1-1" to "2020-01-01"
                                                                                            //$dateString = $year . '-' . $month . '-' . $day;
                                                                                            // Create a DateTime object from the date string
$date_time = $date." ".$time;
$send_data = new \controller\sendData();
$result = $send_data->insertEvent($uid,$title,$date_time,$date,$time,$data);
echo $result;

