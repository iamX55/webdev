<?php

namespace controller;


use UserModel;

include __DIR__.'/../model/UserModel.php';
class UserCredential
{
    private UserModel $userModel;
    public function __construct()
    {
        $this->userModel = new UserModel();
    }


    /** To register User inside Db
     * @param $email
     * @param $password
     * @param $mobile
     * @return array|string|null
     */
    public function userRegister($name,$email,$mobile,$password): array|string|null
    {
        return $this->userModel->registerOperation($name,$email,$mobile,$password);
    }


    public function userLogin($email,$password): bool|array|string
    {
        return $this->userModel->loginOperation($email,$password);
    }

    public function fetchUserId(mixed $email, mixed $mobile): bool|array|null
    {
        return $this->userModel->existUser($email,$mobile);
    }
}