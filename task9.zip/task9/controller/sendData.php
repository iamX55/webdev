<?php

namespace controller;
use model\EventHandle;

include __DIR__.'/../model/EventHandle.php';
class sendData
{
    private $handler;
    function __construct(){
        $this->handler=new EventHandle();
    }
    public function insertEvent($id,$title,$date_time,$date,$time,$json_data){
        return $this->handler->insertOperation($id,$title,$date_time,$date,$time,$json_data);
    }
}