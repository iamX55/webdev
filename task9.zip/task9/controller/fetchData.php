<?php

namespace controller;
use model\EventHandle;

include __DIR__.'/../model/EventHandle.php';
class fetchData
{
    private $handler;
    function __construct(){
        $this->handler=new EventHandle();
    }
    public function getData($date){
        return $this->handler->readOperation($date);
    }
}