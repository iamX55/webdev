<?php

namespace controller;
use model\EventHandle;

include __DIR__.'/../model/EventHandle.php';
class deleteData
{
    private $handler;
    function __construct(){
        $this->handler=new EventHandle();
    }
    public function getData($userId,$date,$slot){
        return $this->handler->deleteOperation($userId,$date,$slot);
    }
    public function authenticateUser($userId,$date,$slot){
        return $this->handler->authenticateOperation($userId,$date,$slot);
    }
}