<?php
    session_start();
    session_unset();
    session_destroy();
    echo "session destroyed";
    header("Location:index.php");