let button_signin = document.getElementById("id_b_signIn");
button_signin.disabled=true;





// function will call at validate field for (on input event)
function validateEmail(input) {
    let emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const regexPattern = /[a-zA-Z0-9]+@/;
    const pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    // Check if the pattern contains "@" symbol

    button_signin.disabled=true;
    if (!regexPattern.test(input.value)) {
        button_signin.disabled=true;
        // displayError("id_emailError","The regular expression does not contain '@'.");
    }else if(!pattern.test(input.value)){
        button_signin.disabled=true;
        // displayError("id_emailError","email do not have correct domain name");
    }
    else if (!emailPattern.test(input.value)){
        button_signin.disabled=true;
        // displayError("id_emailError","**Enter Proper Email Id.");
    } else{
        // displayError("id_emailError","");

        button_signin.disabled=false;
    }
}





function validatePassword(input) {
    let password = input.value;
    let lengthPattern = /^.{8,16}$/;
    let uppercasePattern = /[A-Z]/;
    let specialCharPattern = /[!@#$%^&*]/;
    let digitPattern = /[0-9]/;
    button_signin.disabled=true;
    if (!lengthPattern.test(password)){
        // displayError("id_passwordError","Password should be 8-16 characters ");
        button_signin.disabled=true;
    }
    else if( !uppercasePattern.test(password)){
        // displayError("id_passwordError","must have one Uppercase letters ");
        button_signin.disabled=true;
    }
    else if(!specialCharPattern.test(password)){
        // displayError("id_passwordError","must have one special keyword");
        button_signin.disabled=true;
    }
    else if(!digitPattern.test(password)) {
        // displayError("id_passwordError","must have one digit");
        button_signin.disabled=true;
    }
    else {
        button_signin.disabled=false;
        // displayError("id_passwordError","");
        return true;
    }
    return false;
}