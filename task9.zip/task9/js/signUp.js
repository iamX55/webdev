const firstName = document.getElementById("id_firstName");
const lastName = document.getElementById("id_lastName");
const email = document.getElementById("id_email");
const  mobile = document.getElementById("id_mobile");
const password = document.getElementById("id_password");
let button = document.getElementById("sign_button");
button.disabled=true;




    













    //event will trigger when sign up button will be clicked
    button.addEventListener("click",function(event){

        // let a,b,c,d;
        // event.preventDefault();
        // a = Name_Validate();
        // b = ValidateEmail(email.value);
        // c =  Mobile_Validate(mobile.value);
        // d =  validatePassword(password);
        //
        // if(a)console.log("name done")
        // else console.log("name failed")
        //
        // if(b)console.log("email done")
        // else console.log("email failed")
        //
        // if(c)console.log("mobile done")
        // else console.log("mobile failed")
        //
        // if(d)console.log("password done")
        // else console.log("password failed")

        // if(a && b && c && d){
        //     // document.getElementById('success-message').style.display="flex";
        //     // document.getElementById('main').style.display="none";
        //
        // }
        console.log("button pressed");
        // setTimeout(function(){
        //     document.getElementById('success-message').style.display="none";
        //     document.getElementById('main').style.display="block";
        // },1000);
    });
//On Input Validation
console.clear();

//function to display error
function displayError(inputId,errMsg) {
    const element=document.getElementById(`${inputId}`);
    element.textContent=errMsg;
    element.style.color="red";
    element.style.fontWeight="bolder";
}




// function will call at First Name field for (on input event)
function validateFirstName(input) {
    let namePattern = /^[a-zA-Z ]{2,30}$/;
    button.disabled=true;
    if (!namePattern.test(input.value)) {
        displayError("id_firstError","**First name must have character between 2-30 range");
    } else {
        displayError("id_firstError","");
        button.disabled=false;
    }
}





// function will call at Last Name field for (on input event)
function validateLastName(input) {
    let namePattern = /^[a-zA-Z ]{2,30}$/;
    button.disabled=true;
    if (!namePattern.test(input.value)) {
        displayError("id_lastError","**last name must have only letter");
    } else {
        button.disabled=false;
        displayError("id_lastError","");
    }
}





// function will call at validate field for (on input event)
function validateEmail(input) {
    let emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const regexPattern = /[a-zA-Z0-9]+@/;
    const pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    // Check if the pattern contains "@" symbol
    button.disabled=true;

    if (!regexPattern.test(input.value)) {
        displayError("id_emailError","The regular expression does not contain '@'.");
    }else if(!pattern.test(input.value)){
        displayError("id_emailError","email do not have correct domain name");
    }
    else if (!emailPattern.test(input.value)){
        displayError("id_emailError","**Enter Proper Email Id.");
    } else{
        displayError("id_emailError","");
        button.disabled=false;

    }
}





// function will call at  Mobile number field for (on input event)
function validateMobile(input) {
    let contactPattern = /^\d{10,14}$/;
    button.disabled=true;
    if (!contactPattern.test(input.value)) {
        displayError("id_mobileError","Contact number should contain 10 to 14 digits only.");
    } else {
        button.disabled=false;
        displayError("id_mobileError","");
    }
}






function validatePassword(input) {
    let password = input.value;
    let lengthPattern = /^.{8,16}$/;
    let uppercasePattern = /[A-Z]/;
    let specialCharPattern = /[!@#$%^&*]/;
    let digitPattern = /[0-9]/;
    button.disabled=true;

    if (!lengthPattern.test(password)){
        displayError("id_passwordError","Password should be 8-16 characters ");
    }
    else if( !uppercasePattern.test(password)){
        displayError("id_passwordError","must have one Uppercase letters ");
    }
    else if(!specialCharPattern.test(password)){
        displayError("id_passwordError","must have one special keyword");
    }
    else if(!digitPattern.test(password)) {
        displayError("id_passwordError","must have one digit");
    }
    else {
        button.disabled=false;

        displayError("id_passwordError","");
        return true;
    }
    return false;
}





