const calendar = document.querySelector(".calendar"),
  date = document.querySelector(".date"),
  daysContainer = document.querySelector(".days"),
  prev = document.querySelector(".prev"),
  next = document.querySelector(".next"),
  todayBtn = document.querySelector(".today-btn"),
  gotoBtn = document.querySelector(".goto-btn"),//-=-=-=-==-=go button
  dateInput = document.querySelector(".date-input"),//taking input from calendar
  eventDay = document.querySelector(".event-day"),
  eventDate = document.querySelector(".event-date"),
  eventsContainer = document.querySelector(".events"),//target parent container of event block
  // addEventBtn = document.querySelector(".add-event"),//button below right corner ,to add event to
  addEventTimeBtn = document.querySelectorAll(".add-event1"),
  addEventWrapper = document.querySelector(".add-event-wrapper "),
  addEventCloseBtn = document.querySelector(".close "),
  addEventTitle = document.querySelector(".event-name "),
  addEventFrom = document.querySelector(".event-time-from "),
  addEventTo = document.querySelector(".event-time-to "),
  addEventSubmit = document.querySelector(".add-event-btn ");//to add events inside add-event-body
  btn1 = document.getElementById("button1");
  btn2 = document.getElementById("button2");
  btn3 = document.getElementById("button3");
  btn4 = document.getElementById("button4");
  // btn5 = document.getElementById("button5");
  btn6 = document.getElementById("button6");
  btn7 = document.getElementById("button7");
  btn8 = document.getElementById("button8");
  btn9 = document.getElementById("button9");
  timeFrom = document.getElementById("time-from");
  timeTo = document.getElementById("time-to");
  // let userId=0;
  console.log(userId+"my id");//dynamically loaded (when user will log in)
  let today = new Date();
  let activeDay=today.getDate();
  let month = today.getMonth()+1;
  let year = today.getFullYear();
  console.log(today);
  console.log(`today${year}-${month}-${activeDay}`);






  // All EventsListener
  gotoBtn.addEventListener("click", gotoDate);//triggering go to button
  dateInput.addEventListener("input", (e) => {
  console.log(dateInput.value);
  });//triggering date picker
  todayBtn.addEventListener("click", () => {
    today = new Date();
    activeDay=today.getDate();
    month = today.getMonth()+1;//adding one because .getMonth() function return (0-11) month range value
    year = today.getFullYear();
    initCalendar();
    updateActiveDay();
  });//triggering today button
  prev.addEventListener("click", prevMonth);//event call when click on previous date
  next.addEventListener("click", nextMonth);//event call when next month event call
  btn1.addEventListener("click",popup);//triggring of event when slot button are clicked
  btn2.addEventListener("click",popup);
  btn3.addEventListener("click",popup);
  btn4.addEventListener("click",popup);
  // btn5.addEventListener("click",popup);
  btn6.addEventListener("click",popup);
  btn7.addEventListener("click",popup);
  btn8.addEventListener("click",popup);
  btn9.addEventListener("click",popup);
  addEventCloseBtn.addEventListener("click", () => {
    addEventWrapper.classList.remove("active");
  }); //popup will hide at_clicked close button
  document.addEventListener("click", (e) => {
    // e.target !== addEventBtn &&
    if ( !addEventWrapper.contains(e.target) && !e.target.classList.contains("add-event1") ) {
      addEventWrapper.classList.remove("active");
    }
  });//if user click else where ,popup will be hidden
  addEventTitle.addEventListener("input", (e) => {
  addEventTitle.value = addEventTitle.value.slice(0, 60);
});//allow 50 chars in event title
  addEventSubmit.addEventListener("click", () => {
  const eventTitle = addEventTitle.value;
  const eventTimeFrom = addEventFrom.value;
  const eventTimeTo = addEventTo.value;
      console.log("add submit event triggered1234");
  if (eventTitle === "" || eventTimeFrom === "" || eventTimeTo === "") {
    alert("Please fill all the fields");
    return;
  }else{
      //check if any backdate slot is booking then return
      console.log("add submit event triggered");
      let temp_hour=parseInt(eventTimeTo.split('.')[0]);
      let temp_min = parseInt(eventTimeTo.split('.')[1]);
      if(temp_hour>=1 && temp_hour<6){
          temp_hour+=12;
      }
      let book_date= new Date(year,month-1,activeDay,temp_hour,temp_min);
      let today_date = new Date();
      console.log(book_date)
      console.log(today_date);
      if(book_date<today_date){
          alert("back date or time not possible to book");
          return;
      }

  }

  //check correct time format 24 hour
  // const timeFromArr = eventTimeFrom.split(".");
  // const timeToArr = eventTimeTo.split(".");
  // console.log(timeToArr);
  // console.log(timeFromArr);
  // if (timeFromArr.length !== 2 || timeToArr.length !== 2 || timeFromArr > '23' || timeFromArr[1] > 59 || timeToArr[0] > 23 || timeToArr[1] > 59) {
  //   alert("Invalid Time Format");
  //   return;
  // }

  const timeFrom = convertTime(eventTimeFrom);
  const timeTo = convertTime(eventTimeTo);
  console.log(timeFrom);//12.00 PM
  console.log(timeTo); //1.00 PM
  //create event
  const newEvent = {
    //user_id :
    title: eventTitle,
    date:`${year}-${month}-${activeDay}`,
    time:  timeFrom + " - " +timeTo,

  };
  //push event to the data base-==-==-===


  // check if event is already added or not
  let eventExist = false;
  eventsArr.forEach((event) => {
    //function to check that time slot is empty or not
    let parse_event= JSON.parse(event);
    let match_date=`${year}-${month}-${activeDay}`;
    // if (event.day === activeDay && event.month === month && event.year === year)
    if(match_date===parse_event.date){
      if (parse_event.time === timeFrom + " - " + timeTo) {
        eventExist = true;
      }
    }
  });
  if (eventExist) {
    alert("Slot Already Booked from main");
    return;
  }


  $.ajax({
    url:"storeDataView.php",
    type:"POST",
    data:{data:JSON.stringify(newEvent),id:userId},
    success:function (data){
      // console.log(typeof (data)); return data=="1" if successful insertion happend
      if(data ==="1"){
        eventExist=false;
      }else{
        eventExist=true;
        alert("Slot Already Booked here ");
      }
    }
  });
  //it will wait till database return the response;
  setTimeout(()=>{
    if(eventExist){ return;}
    //hiding pop up
    addEventWrapper.classList.remove("active");
    //filling empty value to pop up fields
    addEventTitle.value = "";
    addEventFrom.value = "";
    addEventTo.value = "";
    updateEvents(activeDay);
    updateSlots(activeDay);
    //select active day and add event class if not added (underline  the day that the day has some events)
    const activeDayEl = document.querySelector(".day");
    if (!activeDayEl.classList.contains("event")) {
        activeDayEl.classList.add("event");
    }
  },1000);
});//when user submit button is clicked for slot booking
  eventsContainer.addEventListener("click", (e) => {
  if (e.target.classList.contains("event")) {
    if (confirm("Are you sure you want to delete this event?")) {
      console.log(e.target);
      //event {e.target}
      //title  [0]
      //fas
      //event-title  [1]
      //userId
      //event-time[1]
      //span
      // const eventTitle = e.target.children[0].children[1].innerHTML;
      let tempId=e.target.children[0].children[2].innerHTML;
      let match_date=`${year}-${month}-${activeDay}`;
      console.log(match_date);
      let slot_detail=e.target.children[1].children[0].innerHTML;
      console.log(slot_detail);
      if( tempId !== userId.toString()){
        alert("you dont have authority of deleting it");
        return;
      }else{
        $.ajax({
          url:"deleteDataView.php",
          type:"POST",
          data:{userId:userId,date:match_date,slot:slot_detail},
          success:function (data){
            if(data==="1"){
              console.log("delete successfully");
            }else if (data==="0"){
              alert("user dont have authority to delete this");
            }else{
              console.log("delete failed");
            }
          }
        });
      }
      // eventsArr.forEach((event) => {
      //   if (event.day === activeDay && event.month === month + 1 && event.year === year)
      //   {
      //     event.events.forEach((item, index) => {
      //
      //         //deleting from array
      //         let timeSlot=item.time.split("-");
      //         let timeStart=timeSlot[0].split(" ")[0];
      //         let timeEnd = timeSlot[1].split(" ")[0];
      //         console.log("time range"+timeSlot[1]+"-"+timeStart+"-"+timeEnd);
      //         addEventTimeBtn.forEach((element)=> {
      //           if (element.innerText === timeStart) {
      //             element.style.backgroundColor = "#b38add";
      //           }
      //         });
      //         ////////////////////////////////////////////
      //         event.events.splice(index, 1);
      //
      //     });
      //     //if no events left in a day then remove that day from eventsArr
      //     if (event.events.length === 0) {
      //       eventsArr.splice(eventsArr.indexOf(event), 1);
      //       //remove event class from day
      //       const activeDayEl = document.querySelector(".day.active");
      //       if (activeDayEl.classList.contains("event")) {
      //         activeDayEl.classList.remove("event");
      //       }
      //     }
      //   }
      // });

      setTimeout(()=>{
        updateSlots(activeDay);
        updateEvents(activeDay);
      },1000);
    }
  }
});//function to delete event when clicked on exist event(right side)





  //All array variable to store valur temporary
  // month value store here
  const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];
  // const eventsArr = [
  //   {
  //     day: 13,
  //     month: 11,
  //     year: 2022,
  //     events: [
  //       {
  //         userid
  //             event_id
  //         title: "Event 1 lorem ipsun dolar sit genfa tersd dsad ",
  //         time: "10:00 AM - 11.00 AM",
  //       },
  //       {
  //         userid
  //             event_id
  //         title: "Event 2",
  //         time: "11:00 AM - 12.00PM",
  //       },
  //     ],
  //   },
  // ];
  const eventsArr = [];
  // getEvents(activeDay,month,year);
  console.log(eventsArr);





  initCalendar();// initializing calendar, first time with respect to today month and year;




  updateActiveDay();





  function updateActiveDay(){
    getActiveDay(activeDay);// setting i'th day to the right top conner
    updateEvents(activeDay);// loading events to the right event section (first fetch from data base through get event);
    updateSlots(activeDay);
  }






  //function to add days in days with class day and prev-date next-date on previous month and next month days and active on today
  function initCalendar() {
    const firstDay = new Date(year, month-1, 1);
    const lastDay = new Date(year, month , 0);
    const prevLastDay = new Date(year, month-1, 0);
    const prevDays = prevLastDay.getDate();
    const lastDate = lastDay.getDate();
    const day = firstDay.getDay();
    const nextDays = 7 - lastDay.getDay() - 1;

    date.innerHTML = months[month-1] + " " + year;
    console.log("date.innerHTML"+month);

    let days = "";
    //adding previous date into calender
    for (let x = day; x > 0; x--) {
      days += `<div class="day prev-date">${prevDays - x + 1}</div>`;
    }
    // adding 1 to till last day into calendar dynamically
    for (let i = 1; i <= lastDate; i++) {
      //check if event is present on that day
      let event = false;
      //adding event to calendar---
      eventsArr.forEach((eventObj) => {
        //day value 1-31
        if (eventObj.day === i && eventObj.month === month  && eventObj.year === year) {
          event = true;
        }
      });

      //if it is today and then load the day to the right part as active day and add the events(if today have some event)
      if ( i === new Date().getDate() && year === new Date().getFullYear() && month === new Date().getMonth()+1){
          // if i'th day is today
          if (event) {
            days += `<div class="day today event">${i}</div>`;
          } else {
            days += `<div class="day today ">${i}</div>`;
          }
      }
      else {
        if (event) {
          days += `<div class="day event">${i}</div>`;
        } else {
          days += `<div class="day ">${i}</div>`;
        }
      }
    }

    // close of date loading




    for (let j = 1; j <= nextDays; j++) {
      days += `<div class="day next-date">${j}</div>`;
    }
    daysContainer.innerHTML = days;
    addListener();//adding event listener to all 30 day inside calendar
  }





  //function to add month and year on prev and next button
  function prevMonth() {
    month--;
    if (month < 1) {
      month = 12;
      year--;
    }
    initCalendar();
  }





  function nextMonth() {
    month++;
    if (month > 12) {
      month = 1;
      year++;
    }
    initCalendar();
  }





  //function to add active on day(if user click any date div inside calender it will fetch data from data base , do updateEvent() UpdateSlot() )
  function addListener() {
    const days = document.querySelectorAll(".day");
    days.forEach((day) => {
      day.addEventListener("click", (e) => {
        //remove active from all dates
        days.forEach((day) => {
          day.classList.remove("active");
        });
        //if clicked prev-date or next-date switch to that month
        if (e.target.classList.contains("prev-date")) {
          prevMonth();
          //add active to clicked day after month is change
          setTimeout(() => {
            //add active where no prev-date or next-date
            const days = document.querySelectorAll(".day");
            days.forEach((day) => {
              //making previous day as active day (if any previous date is pressed)
              if (!day.classList.contains("prev-date") && day.innerHTML === e.target.innerHTML) {
                day.classList.add("active");
              }
            });
          }, 100);
        }
        else if (e.target.classList.contains("next-date")) {
          nextMonth();
          //add active to clicked day after month is changed
          setTimeout(() => {
            const days = document.querySelectorAll(".day");
            days.forEach((day) => {
              if (!day.classList.contains("next-date") && day.innerHTML === e.target.innerHTML) {
                //making next day as active day (if any next date is pressed)
                day.classList.add("active");
              }
            });
          }, 100);
        } else {
          //when any n date is clicked, if it is not next-date/pre-date then make that day active
          e.target.classList.add("active");
        }
        setTimeout(()=>{
          getActiveDay(e.target.innerHTML);//setting the current date as active day (to the top right corner)
          updateEvents(Number(e.target.innerHTML));//updating event to the right side (fetching data from database)
          updateSlots(Number(e.target.innerHTML));
          activeDay = Number(e.target.innerHTML);
        },100);
      });
    });
  }





  //event call when go button will click ,and redirected the calendar to the user input dd-mm--yyyy
  function gotoDate() {
    //function will execute when goto button will trigger(this help to load calendar according to date)
    // console.log("here");
    const dateArr = dateInput.value.split("-");
    // dateArr have YYYY-MM-DD format
    // console.log(dateArr);
    if (dateArr.length === 3) {
      if (dateArr[2] > 0 && dateArr[1] < 13 && dateArr[0].length === 4) {
        if(dateArr[1][0]==='0'){
          month=dateArr[1].slice(1);
          console.log(month);
        }else{
          month=dateArr[1];
        }
        if (dateArr[2][0]==='0'){
          activeDay=dateArr[2].slice(1);
        }else{
          activeDay=dateArr[2];
        }
        console.log(dateArr[0]);
        year = dateArr[0];
        initCalendar();
        updateActiveDay();


        return;
      }
    }
    alert("Invalid Date");
  }






  //function get active day name and date and update to the top right block
  function getActiveDay(date) {
    // Tue Sep 26 2023 11:12:12 GMT+0530 (India Standard Time)
      const day = new Date(year, month-1, date);
      console.log("getActiveDay"+day);
      eventDay.innerHTML = day.toString().split(" ")[0];
      eventDate.innerHTML = date + " " + months[month-1] + " " + year;
      console.log("date.innerHTML"+month);
      console.log("date.innerHTML"+date);
  }






  //function update events according to active_day(day which is clicked by user on calendar)
  function updateEvents(date) {
    //inside date only day value is stored
    //fetching value from database
    getEvents(date,month,year);
    setTimeout(()=>{
      let events = "";
      // {"title":"kkk","date":"2023-9-28","time":"3.00 AM - 4.00 AM"} eventsArr object format
      let match_date = `${year}-${month}-${date}`;
      eventsArr.forEach((event) => {
        // if ( date === event.day && month + 1 === event.month && year === event.year)
        // console.log("hello sakilur");
        let parse_event= JSON.parse(event);
        if( match_date === parse_event.date )
        {
            // console.log("event date matched");

          // event.events.forEach((event) => {wwwwwwwwwwwwwwwwwww
          events += `<div class="event">
                        <div class="title">
                          <i class="fas fa-circle"></i>
                          <h3 class="event-title">${parse_event.title}</h3>
                          <i id="userId" hidden>${userId}</i>
                        </div>
                        <div class="event-time">
                          <span class="event-time">${parse_event.time}</span>
                        </div>
                      </div>`;
          // });wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww

        }else{
          // console.log("eventdate missmatched");
          // console.log(match_date);
          // console.log(event.date);
        }
      });
      if (events === "") {
        events = `<div class="no-event">
                      <h3>No Events</h3>
                </div>`;
      }
      eventsContainer.innerHTML = events;//adding all events to the container
      // saveEvents(); to store information inside local storage;
    },600);

  }





  //function update slots according to active_day(day which is clicked by user on calendar)
    function updateSlots(date){
      let match_date = `${year}-${month}-${date}`;
      console.log("updateSlot");
      console.log(eventsArr);

      addEventTimeBtn.forEach((event)=>{
          event.style.backgroundColor="#b38add";
      });
      setTimeout(()=>{
        eventsArr.forEach((event) => {
          //event format {"title":"kkk","date":"2023-9-28","time":"3.00 AM - 4.00 AM"}
          // if ( date === event.day && month + 1 === event.month && year === event.year)
          let parse_event= JSON.parse(event);
          // console.log(parse_event);
          if(match_date===parse_event.date)
          {
            // event.events.forEach((event) => {
            //time format 10.00 AM - 11.00AM
            let timeSlot=parse_event.time.split("-");
            let timeStart=timeSlot[0].split(" ")[0];
            let timeEnd = timeSlot[1].split(" ")[0];
            // console.log("time range"+timeSlot[1]+"-"+timeStart+"-"+timeEnd);
            addEventTimeBtn.forEach((event)=>{
              if(event.innerText===timeStart){
                event.style.backgroundColor="red";
              }
            });
            // });
          }
        });
      },600);
    }




  // event=clicking on any slot at any date on calendar
  //showing popup and setting the time value to popup
  function popup(event){
    // console.log(event.target.innerText);
    addEventWrapper.classList.toggle("active");
    timeFrom.value=event.target.innerText;
    const numericValue = 1 + parseFloat(event.target.innerText);
    timeTo.value=numericValue+".00";

  }





  //function to get events from  date_base at (dd-mm-yyyy)
  function getEvents(d,m,y) {
    console.log("getEvents triggeres");
    // console.log(`${y}-${m}-${d}`);
      $.ajax({
        url:"fetchDataView.php",
        type:"POST",
        data:{day:d,month:m,year:y},
        success:function (data){
          // console.log(data);//console
          let obj = JSON.parse(data);
          // console.log(obj);
            eventsArr.length=0;//deleting all previous array element
            obj.forEach((value)=>{
              // console.log(value.json_text);
              eventsArr.push(value.json_text);
            });
            // console.log(eventsArr);

        }

      });
    //save data to data Base
    //check if events are already saved in local storage then return event else nothing
    // if (localStorage.getItem("events") === null) {
    //   return;
    // }
    // eventsArr.push(...JSON.parse(localStorage.getItem("events")));
  }





  function convertTime(time) {
  //convert time to 24 hour format
  //convert 13.00 to 1.00AM or PM
  let timeArr = time.split(".");
  let timeHour = timeArr[0];
  let timeMin = timeArr[1];
  let timeFormat;
  if(timeHour>=9 && timeHour<12) {
    timeFormat = "AM";
  }else{
    timeFormat = "PM";
  }
  timeHour = timeHour % 12 || 12;
  time = timeHour + "." + timeMin + " " + timeFormat;
  return time;
}





  window.addEventListener("beforeunload", function (event) {
    event.returnValue = "Write something clever here..";
    $.ajax({

      type: "POST",
      url: "logout.php",
      success:function (e){
        console.log(e);
      }

    });
  });




  //function to save events in local storage
  function saveEvents() {
    // localStorage.setItem("events", JSON.stringify(eventsArr));
    //load data from data base
  }





  //allow only time in event time from and to customize function for later customization
  addEventFrom.addEventListener("click", (e) => {
        e.target.disabled=true;
  });





  // customize function for later edit
  addEventTo.addEventListener("input", (e) => {
        e.target.disabled=true;
  });