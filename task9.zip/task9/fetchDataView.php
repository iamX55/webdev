<?php
include __DIR__.'/controller/fetchData.php';
$day=$_POST["day"];
$month = $_POST["month"];
$year = $_POST["year"];
$date=$year."-".$month."-".$day;
//$date='2023-9-28';
$controller = new \controller\fetchData();
$result  = $controller->getData($date);
//var_dump($result);

$a=json_encode($result);
echo $a;



