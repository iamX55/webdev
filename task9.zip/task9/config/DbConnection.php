<?php

class DbConnection
{
    private mixed $DB_name;
    private mixed $DB_pass;
    private mixed $DB_user;
    private mixed $DB_host;

    public function __construct()
    {
        $config = include(__DIR__ . '/EnvironmentSettings.php');

        $this->DB_host = $config['DbCredential']['host'];
        $this->DB_user = $config['DbCredential']['username'];
        $this->DB_pass = $config['DbCredential']['password'];
        $this->DB_name = $config['DbCredential']['db'];
    }





    /**used to create database connection
     * @return bool|PDO
     */
    public function connect(): bool|PDO
    {
        try {

            $conn = new PDO("mysql:host={$this->DB_host};dbname={$this->DB_name}",$this->DB_user,$this->DB_pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            return $conn;
        }catch (PDOException $e){
            echo $e->getMessage();
            return false;
        }
    }





}