<?php

return
    array(
        'DbCredential' => [
            'host' => 'localhost',
            'username' => 'root',
            'password' => '',
            'db' => 'user'
        ],
        'newDb' => [
            'host' => 'localhost',
            'username' => 'root',
            'password' => '',
            'db' => 'user2'
        ]
    );
