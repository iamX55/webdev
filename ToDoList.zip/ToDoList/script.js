let count_id =0;
let arr=[];
let inputBx = document.querySelector('#inputBx');
let list = document.querySelector('#list');
    inputBx.addEventListener("keyup",function(event){
        if(event.key == 'Enter'){
            arr.push({id:`l${count_id}`,name:this.value});
            addItem(this.value);
            /*.....................................*/
                saveUsers(arr);
            this.value = "";
        }
    })
    const saveUsers=(users)=>{
        localStorage.setItem('users',JSON.stringify(users)); //setting user Array in localstorage
        // displayUsers();
    }


    const deleteUser=(id)=>{
        let indexToRemove = arr.findIndex((pl) => pl.id === id);
        arr.splice(indexToRemove, 1);
        // arr.splice(index,1);
        saveUsers(arr);
    };





















    let addItem = (inputBx) => {
        let listItem = document.createElement("li");
        listItem.setAttribute("id",`l${count_id}`);
        listItem.innerHTML = `<span id="s${count_id}">pending</span><div class="indiv">${inputBx}</div><i id="i${count_id}"></i><a>edit</a>`;
        count_id++;
        let spnn =  listItem.querySelector("span");
        
        listItem.addEventListener("click",function(){
            this.classList.toggle('done');
            if(this.classList.contains('done')){
                spnn.innerText="Done...";
            }else{
                spnn.innerText="Pending";
            }
            
        })
        //code for delete section-----------------------------------------------------------------------------------------------------
        let i =listItem.querySelector("i").addEventListener("click",
            function(){
                deleteUser(listItem.id);
                listItem.remove();
            }
        )
        //code for edit section----------------------------------------------------------------------------------------------------------
        let a = listItem.querySelector("a").addEventListener("click",
            function(){
                var val=listItem.innerText.slice(7,-4);
                // console.log(val);
            //    console.log(typeof(val));
                console.log(listItem.id);
                deleteUser(listItem.id);
                listItem.remove();
                document.querySelector('#inputBx').value=val;
                // console.log(inputBx);
            }
        )
       
        
      
        list.appendChild(listItem);
    }